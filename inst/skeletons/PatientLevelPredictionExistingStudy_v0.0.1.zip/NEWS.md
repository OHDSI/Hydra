SkeletonExistingPredictionModelStudy 0.0.2
======================
  - A skeleton package that can be used to develop studies to externally validate existing prediction models