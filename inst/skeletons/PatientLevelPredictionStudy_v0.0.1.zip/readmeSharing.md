[Add study title]
=============

<img src="https://img.shields.io/badge/Study%20Status-Repo%20Created-lightgray.svg" alt="Study Status: Repo Created">

- Analytics use case(s): **Patient-Level Prediction**
- Study type: **Methods Research**
- Tags: **-**
- Study lead: **add name**
- Study lead forums tag: **[add_username](https://forums.ohdsi.org/u/add_username)**
- Study start date: **month year**
- Study end date: **month year**
- Protocol: **-**
- Publications: **-**
- Results explorer: **-**

[ add a sentance explaining the study]

Suggested Requirements
===================
- R studio (https://rstudio.com)
- Java runtime environment
- Python

Instructions to Install and Execute from GitHub
========================================================

- [Instructions to install the study library from GitHub using Renv (recommended)](STUDY-PACKAGE-SETUP.md)
- [Instructions to install the study library from GitHub using devtools (not recommended)](STUDY-PACKAGE-SETUP-NORENV.md)
- [Instructions to execute the study ](STUDY-PACKAGE-EXECUTE.md)

Results
========================================================
Once executed you will find multiple csv files in the specified outputFolder.
