A Package Skeleton for Patientl-Level Prediction Studies
========================================================

A skeleton package, to be used as a starting point when implementing patient-level prediction studies.

Vignette: [Using the package skeleton for patient-level prediction studies](https://raw.githubusercontent.com/OHDSI/StudyProtocolSandbox/master/SkeletonPredictionStudy/inst/doc/UsingSkeletonPackage.pdf)

Instructions 
===================

- Step 1: Build the package by clicking the 'Install and Restart' button
- Step 2: Run and share the package - to execute the study run:
  ```r
  install.packages("devtools")
  devtools::install_github("OHDSI/PatientLevelPrediction")
  # check the package
  PatientLevelPrediction::checkPlpInstallation()
  
  # install the network package
  devtools::install_github('OHDSI/StudyProtocolSandbox/SkeletonPredictionStudy')
  
  library('SkeletonPredictionStudy')
  connectionDetails <- DatabaseConnector::createConnectionDetails(dbms = 'my dbms e.g., sql server',
                                                                server = 'my server',
                                                                user = 'my username',
                                                                password = 'not telling',
                                                                port = 'port number')
execute(connectionDetails = connectionDetails,
                    cdmDatabaseSchema = 'your cdm schema',
                    cohortDatabaseSchema = 'your cohort schema',
                    cohortTable = "cohort",
                    oracleTempSchema = cohortDatabaseSchema,
                    outputFolder = file.path('SkeletonPredictionStudy','my study results'),
                    createCohorts = T,        
					runAnalyses = T,
					createValidationPackage = F,
					packageResults = T,
					minCellCount = 5,
					cdmVersion = 5)
```
- Step 3: You can then easily transport these results into a network study package by copying this package https://github.com/OHDSI/StudyProtocolSandbox/tree/master/PredictionNetworkStudySkeleton and running:
  ```r
  code to come soon
```


# Development status

Under development. Do not use