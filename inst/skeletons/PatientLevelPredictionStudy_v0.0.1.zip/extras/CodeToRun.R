library(SkeletonPredictionStudy)

# Optional: specify where the temporary files (used by the ff package) will be created:
options(fftempdir = "s:/FFtemp")

# If you are creating the study then run:
## createStudyFiles(baseUrl='http://api.ohdsi.org:80/WebAPI',   
##                  packageName='SkeletonPredictionStudy')

# The folder where the study intermediate and result files will be written:
outputFolder <- "./SkeletonPredictionStudy"

# Details for connecting to the server:
dbms <- "pdw"
user <- NULL
pw <- NULL
server <- Sys.getenv('server')
port <- Sys.getenv('port')

connectionDetails <- DatabaseConnector::createConnectionDetails(dbms = dbms,
                                                                server = server,
                                                                user = user,
                                                                password = pw,
                                                                port = port)

execute(connectionDetails = connectionDetails,
        cdmDatabaseSchema = 'cdm database schema',
        cohortDatabaseSchema = 'work database schema',
        cohortTable = "spcohort",
        outputFolder = outputFolder,
        createCohorts = T,
        runAnalyses = TRUE,
        packageResults = F, 
        createValidationPackage = F,
        minCellCount= 5)
