A Package Skeleton for Comparative Effectiveness Studies
========================================================

A skeleton package, to be used as a starting point when implementing comprative effect studies.

* Vignette: [Using the package skeleton for comparative effectiveness studies](https://github.com/OHDSI/SkeletonComparativeEffectStudy/raw/master/inst/doc/UsingSkeletonPackage.pdf)
* Vignette: [Comparative effectiveness studies data model](https://github.com/OHDSI/SkeletonComparativeEffectStudy/raw/master/inst/doc/DataModel.pdf)

# Development status

Under development. Do not use
