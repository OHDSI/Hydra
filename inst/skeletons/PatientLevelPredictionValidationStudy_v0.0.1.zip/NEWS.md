SkeletonPredictionValidationStudy 1.0.4
======================
  - Added r and python environments

SkeletonPredictionValidationStudy 1.0.3
======================
  - Added ability to run models saved as jsons
  - Added ability to run existing model/s saved as json/s


SkeletonPredictionValidationStudy 0.0.1
======================
  - A skeleton package that can be used to externally validate patient-level prediction models
