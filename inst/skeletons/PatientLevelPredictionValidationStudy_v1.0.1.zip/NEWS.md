SkeletonPredictionValidationStudy 0.0.1
======================
  - A skeleton package that can be used to externally validate patient-level prediction models
