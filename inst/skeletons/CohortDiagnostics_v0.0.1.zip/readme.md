A Package Skeleton for Cohort Diagnostics
========================================================

A skeleton package, to be used as a starting point when implementing Cohort Diagnostics


Suggested Requirements
===================
- R studio (https://rstudio.com)


Instructions To Build Package
===================

- Open the package project (file ending with '.Rproj') by double clicking it
- Install any missing dependencies for the package by running:
```r
source('./extras/packageDeps.R')
```
- Build the package by clicking the R studio 'Install and Restart' button in the build tab (top right)



Instructions To Run Study
===================
- Execute the study by running the code in (extras/CodeToRun.R) :


The 'createCohorts' option will create the target and outcome cohorts into cohortDatabaseSchema. 


# Development status
Under development. Do not use
